<?php
    // Autor der Session Initialisierung: Daniel Tatzel
    session_set_cookie_params(10800);   // Cookie bleibt 3 Stunden aktiv
    session_start();                    // Initialisiert die Session
?> 
